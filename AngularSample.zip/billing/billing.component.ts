﻿import { Component, OnInit } from '@angular/core';
import { FormGroup, ReactiveFormsModule, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Billing } from '../../../tiers/billing';
import { BillingErrors } from '../../../tiers/validation/validation.errors';
import { BillingService } from '../../../services/billing.service';

@Component({
    selector: 'billing',
    templateUrl: './billing.component.html',
    styleUrls: ['./billing.component.css'],
})
export class BillingComponent implements OnInit {

    billingForm: FormGroup;
    submitted: boolean = false;
    regErrors = new BillingErrors();
    formErrors = {
    };
    listOfCustomerServiceLevels : any;
    customerServiceLevels = ['Basic', 'Advanced', 'Platinum'];

    constructor(private fb: FormBuilder, private rs: BillingService) { }
    ngOnInit(): void
    {
        this.submitted = true;
        this.buildForm()
    }

    Methods
    getData() : void 
    {
        this.rs.retrieveComponents();
        this.rs.retrieveCustomerServiceLevels();
    }
    onSubmit({ value, valid }: { value: Billing, valid: boolean }) : void
    {
        this.rs.createBilling(value)
            .subscribe(
            response => this.displayErrorsFromServer(response),
            error => console.log('post error: ' + error)
            );
    }
    buildForm(): void
    {
        this.constructFormGroup();
        this.getData();

        this.billingForm.valueChanges
            .subscribe(data => this.onValueChanged(data));

        this.onValueChanged(); 
    }
    constructFormGroup() : void 
    {
        this.billingForm = this.fb.group({
        });
    }
    displayErrorsFromServer(value: any)
    {
        if (value.text() != '')
        {
            var err = JSON.parse(value.text());

            for (const field in this.formErrors) {
                if (err.ModelState['model.' + field] != undefined) { this.formErrors[field] = err.ModelState['model.' + field][0]; }
            }
        }
    }
    onValueChanged(data?: any) {
        if (!this.billingForm) { return; }
        const form = this.billingForm;

        for (const field in this.formErrors) {
            this.formErrors[field] = '';
            const control = form.get(field);

            if (control && control.dirty && !control.valid) {
                const messages = this.regErrors.validationMessages[field];

                for (const key in control.errors) {
                    this.formErrors[field] += messages[key] + ' ';
                }
            }
        }
    }
    resetForm(): void 
    {
        this.billingForm.reset();
    }
}//end export class

