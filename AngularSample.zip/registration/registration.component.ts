﻿import { Component, OnInit } from '@angular/core';
import { FormGroup, ReactiveFormsModule, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Registration } from '../../../tiers/registration';
import { RegistrationErrors } from '../../../tiers/validation/validation.errors';
import { RegistrationService } from '../../../services/registration.service';


@Component({
    selector: 'registration',
    templateUrl: './registration.component.html',
    styleUrls: ['./registration.component.css'],
})
export class RegistrationComponent implements OnInit {

    //Variables
    registrationForm: FormGroup;
    submitted: boolean = false;
    regErrors = new RegistrationErrors();
    formErrors = {
        'FirstName': '',
        'LastName': '',
        'BusinessName': '',
        'WorkPhone': '',
        'MobilePhone': '',
        'Street1': '',
        'Street2': '',
        'Street3': '',
        'City': '',
        'State': '',
        'ZipCode': '',
        'EmailAddress': '',
        'UserName': '',
        'Password': '',
        'ConfirmPassword':''
    };
    listOfStates : any;
    states = ['CA', 'MD', 'OH', 'VA'];

    //Constructor
    constructor(private fb: FormBuilder, private rs: RegistrationService) { }
    ngOnInit(): void
    {
        this.submitted = true;
        this.buildForm()
    }


    Methods
    getData() : void 
    {
        this.rs.retrieveStates();
    }
    onSubmit({ value, valid }: { value: Registration, valid: boolean }) : void
    {
        this.rs.createRegistration(value)
            .subscribe(
            response => this.displayErrorsFromServer(response),
            error => console.log('post error: ' + error)
            );
    }
    buildForm(): void
    {
        this.constructFormGroup();
        this.getData();

        this.registrationForm.valueChanges
            .subscribe(data => this.onValueChanged(data));
        this.onValueChanged(); 
    }
    constructFormGroup() : void 
    {
        this.registrationForm = this.fb.group({
            FirstName: ['',
                [
                    Validators.required,
                    Validators.minLength(1),
                    Validators.maxLength(25)
                ]],

            LastName: ['',
                [
                    Validators.required,
                    Validators.minLength(1),
                    Validators.maxLength(25)
                ]],

            BusinessName: ['',
                [
                    Validators.required,
                    Validators.minLength(1),
                    Validators.maxLength(500)
                ]],

            WorkPhone: ['',
                [
                    Validators.required,
                    Validators.minLength(10),
                    Validators.maxLength(10)
                ]],

            MobilePhone: ['',
                [
                    Validators.required,
                    Validators.minLength(10),
                    Validators.maxLength(10)
                ]],

            Street1: ['',
                [
                    Validators.required,
                    Validators.maxLength(25)
                ]],

            Street2: ['',
                [
                    Validators.maxLength(25)
                ]],

            Street3: ['',
                [
                    Validators.maxLength(25)
                ]],

            City: ['',
                [
                    Validators.required,
                    Validators.minLength(1),
                    Validators.maxLength(25)
                ]],

            State: ['',
                [
                    Validators.required
                ]],

            ZipCode: ['',
                [
                    Validators.required,
                    Validators.minLength(5),
                    Validators.maxLength(10)
                ]],

            EmailAddress: ['',
                [
                    Validators.required,
                    Validators.pattern('^(([\w-]+\.)+[\w-]+|([a-zA-Z]{1}|[\w-]{2,}))((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\.([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\.([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\.([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|([a-zA-Z0-9]+[\w-]+\.)+[a-zA-Z]{1}[a-zA-Z0-9-]{1,23})$'),
                    Validators.maxLength(100)
                ]],

            UserName: ['',
                [
                    Validators.required,
                    Validators.minLength(6),
                    Validators.maxLength(25)
                ]],

            Password: ['',
                [
                    Validators.required,
                    Validators.minLength(6),
                    Validators.maxLength(12)
                ]],

            ConfirmPassword: ['',
                [
                    Validators.required,
                    Validators.minLength(6),
                    Validators.maxLength(12)
                ]]
        });
    }
    displayErrorsFromServer(value: any)
    {
        if (value.text() != '')
        {
            var err = JSON.parse(value.text());

            for (const field in this.formErrors) {
                if (err.ModelState['model.' + field] != undefined) { this.formErrors[field] = err.ModelState['model.' + field][0]; }
            }
        }
    }
    onValueChanged(data?: any) {
        if (!this.registrationForm) { return; }
        const form = this.registrationForm;

        for (const field in this.formErrors) {
            this.formErrors[field] = '';
            const control = form.get(field);

            if (control && control.dirty && !control.valid) {
                const messages = this.regErrors.validationMessages[field];
                for (const key in control.errors) {
                    this.formErrors[field] += messages[key] + ' ';
                }
            }
        }
    }
    resetForm(): void 
    {
        this.registrationForm.reset();
    }
}

